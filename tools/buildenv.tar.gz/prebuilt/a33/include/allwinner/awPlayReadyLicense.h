#ifndef AW_PLAYREADY_LICENSE_H
#define AW_PLAYREADY_LICENSE_H


int doLicensing(const char *la_url);

#endif /* AW_PLAYREADY_LICENSE_H */
