/*
 * Copyright (c) 2008-2016 Allwinner Technology Co. Ltd.
 * All rights reserved.
 *
 * File : cdx_config.h
 * Description : cedarx config header
 * History :
 *
 */

#ifndef CDX_CONFIG_H
#define CDX_CONFIG_H

#endif
