#! /bin/sh

./configure --host=arm-linux --prefix=${ZK_PREFIX} \
	--disable-caca --disable-ozone --disable-ffmpeg --disable-ssa --disable-d3d9 --disable-d3d10 --disable-d3d11 --disable-d3d12 --disable-d3dx \
	--disable-vg --disable-stb_font --disable-stb_vorbis --disable-v4l2 --disable-vulkan --disable-vulkan_display --disable-cdrom --disable-qt --disable-hid --disable-libusb --enable-debug \
	--disable-udev --disable-wasapi --disable-winmm --disable-dsound --disable-cg --enable-sdl2 --disable-sdl --disable-kms \
	--disable-x11 --disable-wayland --disable-builtinzlib --disable-xvideo --disable-videocore --disable-xrandr --disable-xinerama --disable-materialui --disable-xmb \
	--disable-sixel --disable-dsound --disable-miniupnpc --disable-builtinminiupnpc --disable-flac --disable-xaudio --disable-networkgamepad --disable-netplaydiscovery \
	--disable-videoprocessor --disable-easteregg --disable-ssl --disable-overlay --disable-oss --disable-alsa

make clean
make -j4
make install
